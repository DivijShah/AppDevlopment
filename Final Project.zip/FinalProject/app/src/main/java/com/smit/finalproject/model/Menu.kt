package com.smit.finalproject.model

data class Menu(

    val id:Int,
    val name: String,
    val cpp: String

)